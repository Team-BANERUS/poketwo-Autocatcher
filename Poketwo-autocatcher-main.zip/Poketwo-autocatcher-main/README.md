# Poketwo-Autocatcher
This selfbot was designed to automatically catch Pokemon spawned on Discord by Poketwo bot.

![Works](https://media1.giphy.com/media/9cepV83q9ZVW8vAJ2w/giphy.gif)
![Works](https://media0.giphy.com/media/gIG0Aw7vFsU8fKKywD/giphy.gif)
![Works](https://cdn.discordapp.com/attachments/504587263242534913/780038260457209856/20201122_171216_edited.jpg)
![Works](https://cdn.discordapp.com/attachments/504587263242534913/780038815850823701/20201122_171514_edited.jpg)
![Works](https://media4.giphy.com/media/fMH1ennRztVJkjtvRr/giphy.gif)
# Feature
1. Ignore server or channel by IDs. (channels it should work only)

2. Automatically Catch All pokemons! (Poketwo Autocatcher)

3.check Balance,pokes that the bot has caught.

4. it works 24 hours a day!

5. Regularly maintained.

6.you can make bot say anything u want (  for ex:- +say p!info latest, +say p!trade  )

7.Many more...
# How to get it
1. Join Our discord server.
2. star this repo and Paypal me.
3. If you want me to setup, feel free to send me a DM.

# Discord Server
1. link:- [discord server](https://discord.gg/8VhA4mz4NS)
# Setting Up

- You will only require the token of the account you want to run this bot on, it's better if it's an alt as self-bots violate ToS and you can get banned. To grab your token visit [this page](https://github.com/TheRacingLion/Discord-SelfBot/wiki/Discord-Token-Tutorial).
- For further configuration you'll Just need to start the bot.

# Disclaimer
1. I (and others contributors) are not responsible for any actions you perform using it. Use it at your own risk.
2. Selfbots violate Discord TOS and PokeTwo TOS and if you get caught using it, you will get banned. Be careful about how you use the bot.
3. I would not recommend use this self-bot in public servers (especially Official PokeTwo Servers)

# Terms & Conditions
1. You will receive the bot with the deployment instructions after the payment has been acknowledged.
2. Since Poketwo keeps updating , Stay patient until I patch the error for it.
3. All donations are non-refundable.
4. I (and others contributors) for this repo not responsible for any legal suits.
